import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        new Menu(new Scanner(System.in)).start();
    }

}