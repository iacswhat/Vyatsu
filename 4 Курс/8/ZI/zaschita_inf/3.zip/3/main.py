import interface as huita_ebanaya

def main():
    huita_ebanaya.init()

if __name__ == "__main__":
    main()